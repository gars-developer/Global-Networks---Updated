ATTRIBUTE.name = "Strength"
ATTRIBUTE.desc = "A measure of how strong you are."
--ATTRIBUTE.startingMax = 10
--ATTRIBUTE.noStartBonus = false