

PLUGIN.name = "Observer Plus"
PLUGIN.author = "Ratio"
PLUGIN.desc = "Adds on to the no-clip mode to prevent intrusion and enhances ESP functionality."

if (CLIENT) then
    NUT_CVAR_ADMINESPAVANCED = CreateClientConVar("nut_obsespadvanced", 1, true, true)
    NUT_CVAR_ALWAYSONESP_OBSERVER = CreateClientConVar("nut_alwaysonesp_observer", 0, true, true)

    local dimDistance = 1024

    function PLUGIN:HUDPaint()
        local client = LocalPlayer()
        local isNoClip = client:GetMoveType() == MOVETYPE_NOCLIP
        local showESP = isNoClip

        if (client:IsAdmin()) then
            if (NUT_CVAR_ALWAYSONESP_OBSERVER:GetBool() and not (client:IsUserGroup("seniormanagement") or client:IsUserGroup("superadmin"))) then
                RunConsoleCommand("nut_alwaysonesp_observer", "0")
                nut.util.notify("You do not have permission to use Always On ESP for Observer.", client)
            else
                showESP = showESP or NUT_CVAR_ALWAYSONESP_OBSERVER:GetBool()
            end

            if (showESP and not client:InVehicle() and NUT_CVAR_ADMINESPAVANCED:GetBool()) then
                local sx, sy = ScrW(), ScrH()

                for k, v in ipairs(player.GetAll()) do
                    if (v == client) then continue end

                    local scrPos = v:GetPos():ToScreen()
                    local marginx, marginy = sy * 0.1, sy * 0.1
                    local x, y = math.Clamp(scrPos.x, marginx, sx - marginx), math.Clamp(scrPos.y, marginy, sy - marginy)
                    local teamColor = team.GetColor(v:Team())
                    local distance = client:GetPos():Distance(v:GetPos())
                    local factor = 1 - math.Clamp(distance / dimDistance, 0, 1)
                    local size = math.max(10, 32 * factor)
                    local alpha = math.Clamp(255 * factor, 80, 255)
                    local sizeW = math.max(70, 200 * factor)
                    local sizeH = math.max(10, 30 * factor)
                    local squareSize = math.max(10, 32 * factor)

                    surface.SetDrawColor(teamColor.r, teamColor.g, teamColor.b, alpha)
                    
                    local yPos = y + squareSize / 2 + 10
                    local BarOffset = 8 * factor

                    surface.SetDrawColor(0, 0, 0, alpha)
                    surface.DrawRect(x - sizeW / 2, yPos, sizeW, sizeH)

                    local HPDelta = math.Clamp(v:Health() / v:GetMaxHealth(), 0, 1)
                    local HPColor = Color(183, 8, 0)
                    surface.SetDrawColor(HPColor.r, HPColor.g, HPColor.b, alpha)
                    surface.DrawRect(x - (sizeW - BarOffset) / 2, yPos + (BarOffset / 2), (sizeW - BarOffset) * HPDelta, sizeH - BarOffset)

                    local textCol = Color(255, 255, 255, alpha)
                    draw.SimpleTextOutlined(v:Health(), "nutSmallFont", x, yPos + sizeH / 2, textCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, alpha))

                    yPos = yPos + sizeH + 5

                    if (v:Armor() > 0) then
                        surface.SetDrawColor(0, 0, 0, alpha)
                        surface.DrawRect(x - sizeW / 2, yPos, sizeW, sizeH)
                        local ArmorDelta = math.Clamp(v:Armor() / 100, 0, 1)
                        local ArmorColor = Color(0, 0, 255)
                        surface.SetDrawColor(ArmorColor.r, ArmorColor.g, ArmorColor.b, alpha)
                        surface.DrawRect(x - (sizeW - BarOffset) / 2, yPos + (BarOffset / 2), (sizeW - BarOffset) * ArmorDelta, sizeH - BarOffset)

                        textCol = Color(255, 255, 255, alpha)
                        draw.SimpleTextOutlined(v:Armor(), "nutSmallFont", x, yPos + sizeH / 2, textCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, alpha))

                        yPos = yPos + sizeH + 5
                    end
					--cal citizenTeams = {
						--["civilian"] = true,
						--["daf"] = true,
						--["delivery"] = true,
						--["igfarben"] = true,
						--["jobstores"] = true,
					--	["jobreichsbank"] = true,
						--["miningjob"] = true,
						--["taxi"] = true,

					--}

					--local partyTeams = {
					--	["fbk"] = true,
					---	["nsdap"] = true,
					---	["nsdapsa"] = true,
					--}

					--local stateTeams = {
					--	["ssrad"] = true,
					--	["state"] = true,
					--	["rsd"] = true,
					--}

					--local armyTeams = {
					--	["okh"] = true,
					--	["okl"] = true,
					---	["okm"] = true,
					---	["okw"] = true,
					---	["wk3"] = true,
					--}

				--	local ssTeams = {
					--	["ssallg"] = true,
					--	["sslss"] = true,
					---	["ssorpo"] = true,
					--	["ssrsha"] = true,
					----	["jobstores"] = true,
					---	["jobreichsbank"] = true,
					---	["miningjob"] = true,
					---	["tax"] = true,
					--}

					--local colorToUse

					--if citizenTeams[nut.faction.indices[v:Team()].uniqueID] then
					--	colorToUse = Color(94, 185, 76, alpha)
					--elseif partyTeams[nut.faction.indices[v:Team()].uniqueID] then
					--	colorToUse = Color(255, 171, 0, alpha)
					--elseif stateTeams[nut.faction.indices[v:Team()].uniqueID] then
					--	colorToUse = Color(0, 196, 255, alpha)
					--elseif armyTeams[nut.faction.indices[v:Team()].uniqueID] then
					--	colorToUse = Color(102, 209, 70, alpha)
					--elseif ssTeams[nut.faction.indices[v:Team()].uniqueID] then
					--	colorToUse = Color(255, 0, 0, alpha)
					--else
					--	colorToUse = Color(255, 105, 180, alpha)
					--end

                    draw.SimpleTextOutlined(v:Name():gsub("#", "\226\128\139#"), "nutSmallFont", x, yPos, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, alpha))
                    yPos = yPos + 20

					local activeWep = v:GetActiveWeapon()
					if (IsValid(activeWep)) then
						local weaponName = activeWep:GetPrintName()
						local ammoCount = activeWep:Clip1()
						local reserveAmmo = v:GetAmmoCount(activeWep:GetPrimaryAmmoType())

						if (ammoCount >= 0 and reserveAmmo >= 0) then
							weaponName = weaponName .. " [" .. ammoCount .. "/" .. reserveAmmo .. "]"
						end
						
						draw.SimpleTextOutlined(weaponName, "nutSmallFont", x, yPos, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, alpha))
					end
                end
            end
        end
    end

    function PLUGIN:SetupQuickMenu(menu)
        if (LocalPlayer():IsAdmin()) then
            menu:addCategory(self.name)

            local buttonESPAdvanced = menu:addCheck("Toggle ESP Advanced", function(panel, state)
                if (state) then
                    RunConsoleCommand("nut_obsespadvanced", "1")
                else
                    RunConsoleCommand("nut_obsespadvanced", "0")
                end
            end, NUT_CVAR_ADMINESPAVANCED:GetBool())

            local buttonAlwaysOn = menu:addCheck("Always On (Observer)", function(panel, state)
                if (state) then
                    if (LocalPlayer():IsUserGroup("seniormanagement") or LocalPlayer():IsUserGroup("superadmin")) then
                        RunConsoleCommand("nut_alwaysonesp_observer", "1")
                    else
                        nut.util.notify("You do not have permission to use Always On ESP for Observer.", LocalPlayer())
                    end
                else
                    RunConsoleCommand("nut_alwaysonesp_observer", "0")
                end
            end, NUT_CVAR_ALWAYSONESP_OBSERVER:GetBool())

            menu:addSpacer()
        end
    end
else
    -- Server-side logic
    function PLUGIN:PlayerNoClip(client, state)
        -- Observer mode is reserved for administrators.
        if (client:IsAdmin()) then
            if (state) then
                -- Store their old position and looking at angle.
                client.nutObsData = {client:GetPos(), client:EyeAngles()}
                -- Cloaking (make player invisible in observer mode)
                client:SetNoDraw(true)
            else
                if (client.nutObsData) then
                    -- Move the player back if they want.
                    if (client:GetInfoNum("nut_obstpback", 0) > 0) then
                        local position, angles = client.nutObsData[1], client.nutObsData[2]

                        -- Do it the next frame since the player can not be moved right now.
                        timer.Simple(0, function()
                            client:SetPos(position)
                            client:SetEyeAngles(angles)
                            -- Make sure they stay still when they get back.
                            client:SetVelocity(Vector(0, 0, 0))
                        end)
                    end

                    -- Delete the old data.
                    client.nutObsData = nil
                end

                -- Uncloak the player
                client:SetNoDraw(false)
            end
        end
    end
end