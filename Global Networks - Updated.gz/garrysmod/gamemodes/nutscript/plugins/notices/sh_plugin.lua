PLUGIN.name = "Notices"
PLUGIN.author = "Cheesenut"
PLUGIN.desc = "Adds a panel for notifications."

nut.util.include("cl_notice.lua")
