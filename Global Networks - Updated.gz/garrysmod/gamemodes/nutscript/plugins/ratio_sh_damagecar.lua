
local PLUGIN = PLUGIN

PLUGIN.name = "Passenger Damage Transfer"
PLUGIN.author = "Ratio"
PLUGIN.desc = "Passengers and drivers damage."

local function TransferSeatDamageToPlayer(seat, dmgInfo)
    if seat:IsVehicle() then
        if seat:GetClass() == "gmod_sent_vehicle_fphysics_base" then
            local player = seat:GetDriver()
            if IsValid(player) then

                local hitPos = dmgInfo:GetDamagePosition()

                local playerPos = player:GetPos()

                local thresholdDistance = 53 -- example distance in units
                if hitPos:Distance(playerPos) <= thresholdDistance then

                    local newHealth = player:Health() - (dmgInfo:GetDamage()*0.3) -- a bit more than half damage
                    if newHealth > 0 then
                        player:SetHealth(newHealth)
                    else
                        player:Kill()
                    end
                end
            end
        end
    end
end

-- Hook into the EntityTakeDamage event to process damage to vehicle seats
function PLUGIN:EntityTakeDamage(entity, dmgInfo)
    TransferSeatDamageToPlayer(entity, dmgInfo)
end